
You can NOT reload qone with map, changelevel, or by normal single player respawn.
This is new map tech and those methods will fail.  If you need to, use savegame to save your progress.


---------------------------------------------------------------------------

                    Q one

