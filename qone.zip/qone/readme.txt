---------------------------------------------------------------------------

    .d'     'b.
   d'         `b
 .$'           `$.                                          .
 dF             9b     0$     $H         $.         0H    .P       0H   `$
 $L             J$     $$     $$        /`$.        $$  .dP        $$
 Y$             $P     $$     $$       /' $$.       $$*'Y$b.       $$*
 `$\    9$F    /$'     $$     $$      /' `"$$.      $$    `$b      $$
  `$\.  8$8  ./$'      Y$.   .$P     /'     $$.     $$      $      "$  .:$
    "$$##$##$$"         `'"#"'`                             '       `"'`"'
      `"Y#P"'
        |$|
        `$'                          " Q one "
         $
         *
---------------------------------------------------------------------------
(logo viewed best in fixed width / terminal fonts)


beta Release

1.0    - released 12.23.14
1.0.4 - released 12.31.14

---------------------------------------------------------------------------

readme.txt update: 12.31.14
---------------------------------------------------------------------------

Instructions - unpack this file in your quake directory

unzip qone.zip


to launch singleplayer game:

Linux:
   ./maphack-glx -game qone +map qone
   ./q1  # bash scipt runs the above command

win:
   maphack.exe -game qone +map qone
   or click on qone.bat to run this command


to launch (real) coop game:

Linux:
   ./maphack-glx -listen 4 -game qone +coop 1 +exec coop.cfg +map qone

win:
   maphack.exe  -listen 4 -game qone +coop 1 +exec coop.cfg +map qone
   or click on qone-coop.bat to run this command


Deathmatch will function as normal.  There are 32 map sections.
Good luck with this.

   ./maphack-glx -listen 32 -game qone +map qone
   ./maphack-glx -dedicated 32 -game qone +map qone


* To connect a client to a listen or dedicated coop /dm server:

Linux:
./maphack-glx -game qone

Win:
maphack.exe  -game qone

If you know the ip address of the server enter in the console:
connect {ip address}

Or:

From the main menu, select in sequence:
Multiplayer
Join a game
search for games

Select the ip address of the server you wish to play.


Note:

"+exec coop.cfg" is required for regular coop play

---------------------------------------------------------------------------

Game play:

Plays just like quake.

Without any wimpy breaks.  Suck it up Marine!

You run, you shoot, you get runes, you stop shubbs or you die.

---------------------------------------------------------------------------

Other notes:

You MUST use the included maphack engine.  Q one will not run correctly
on any other quake engine.  Contact me if you want the engine source.

You can NOT reload qone with map, changelevel, or by normal single player respawn.
This is new map tech and those methods will fail.  If you need to, use savegame to save your progress.
If you want to restart - you have to quit and reload the engine.

When you respawn you have the standard 2 mins to go find your pack of goodies.
Try not to die in lava.  If you lose a key - they eventually come back.  Just wait.

Intermission messages are set to scroll on the infobar at the bottom of the screen.
To turn them off, enter in the console:

sv_intermis		0

I would like to see someone make a "quake done quick" continuous run through qone.

***
You must provide your own quake one install!
This mod comes with one used map - qone.bsp.  It is less than 100K.
It does not contain any quake one map data.
I repeat - this is NOT an all-in-one quake map.
This is a new map tech that loads existing quake maps into one server.

---------------------------------------------------------------------------
Source code distribution for GPL portions hosted on ".qc" and git.
View download page for details:
http://www.moddb.com/mods/quake-hack/downloads

* This is _beta_ qc / engine code - it might still contain bugs.

---------------------------------------------------------------------------

Bots:

Bots were not included in the 1.0 release.
They may be included in a future release for coop play.  After I test them.



Have fun!

---------------------------------------------------------------------------

                    Q one

