---------------------------------------------------------------------------

    .d'     'b.
   d'         `b
 .$'           `$.                                          .
 dF             9b     0$     $H         $.         0H    .P       0H   `$
 $L             J$     $$     $$        /`$.        $$  .dP        $$
 Y$             $P     $$     $$       /' $$.       $$*'Y$b.       $$*
 `$\    9$F    /$'     $$     $$      /' `"$$.      $$    `$b      $$
  `$\.  8$8  ./$'      Y$.   .$P     /'     $$.     $$      $      "$  .:$
    "$$##$##$$"         `'"#"'`                             '       `"'`"'
      `"Y#P"'
        |$|                       H  H   AA    CCC  K  K
        `$'                       HHHH  A__A  C     KKK
         $                        H  H  A  A   CCC  K  K
         *
---------------------------------------------------------------------------
(logo viewed best in fixed width / terminal fonts)


beta Release

1.4.3 - released 12.31.15

---------------------------------------------------------------------------

readme.txt update: 12.31.15
---------------------------------------------------------------------------

Instructions - unpack this file in your quake directory

unzip qh1.zip


You can also use the included bash / batch files to launch: qh, q1.

to launch singleplayer game:

Linux:
   ./maphack-glx -game quake_hack +map qh_0000

win:
   maphack.exe -game quake_hack +map qh_0000


to launch (real) coop game:

Linux:
   ./maphack-glx -listen 4 -game quake_hack +coop 1 +exec coop.cfg +map qh_0000

win:
   maphack.exe  -listen 4 -game quake_hack +coop 1 +exec coop.cfg +map qh_0000


Deathmatch functions similar to normal.  The map is endless - good luck with this.

   ./maphack-glx -listen 32 -game quake_hack +map qh_0000
   ./maphack-glx -dedicated 32 -game quake_hack +map qh_0000


* To connect a client to a listen or dedicated dm / coop server:

Linux:
./maphack-glx -game quake_hack

Win:
maphack.exe  -game quake_hack

If you know the ip address of the server enter in the console:
connect {ip address}

Or:

From the main menu, select in sequence:
Multiplayer
Join a game
search for games

Select the ip address of the server you wish to play.


Bonus:

"Q one" - launch with "+map qone" to play through quake 1 levels.

Note:

"+exec coop.cfg" is required for regular coop play

---------------------------------------------------------------------------

Game play:

Plays just like quake.

Without any wimpy breaks.  Suck it up Marine!

---------------------------------------------------------------------------

Other notes:

You can NOT reload quake_hack with map, changelevel, or by normal single player respawn.
This is new map tech and those methods will fail.  If you need to, use savegame to save your progress.

When you respawn you have the standard 2 mins to go find your pack of goodies.
Try not to die in lava.  If you lose a key in lava, etc. - they eventually come back.  Just wait.

Runs on "1.4.3 build 4" map_hack tech.  Plays similar to quake.
Minimal set of features.  Builds a random map from random chunks.
There are some weapons and monsters.  I suggest you run.

For now I left everything on random.  Soon there will be "theme" areas.
I.e. you start with base architecture, and slowly explore to castles, etc.

Plans: boss battle rooms you cant leave until the boss is dead.
Special treasures for the boss room.  Key locked areas (and mini boss
battles for the keys.)  More weapons and monsters.  Maybe a bit less random.


---------------------------------------------------------------------------
Source code distribution for GPL portions hosted on ".qc" and git.
View download page for details:
http://www.moddb.com/mods/quake-hack/downloads

* This is _beta_ qc / engine code - it might still contain bugs.

---------------------------------------------------------------------------

Bots:

Bots were not included in the 1.4.3 release.
They may be included in a future release.  After I test them.



Have fun!

---------------------------------------------------------------------------

                    Quake Hack

