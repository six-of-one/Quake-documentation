---------------------------------------------------------------------------

    .d'     'b.
   d'         `b
 .$'           `$.                                          .
 dF             9b     0$     $H         $.         0H    .P       0H   `$
 $L             J$     $$     $$        /`$.        $$  .dP        $$
 Y$             $P     $$     $$       /' $$.       $$*'Y$b.       $$*
 `$\    9$F    /$'     $$     $$      /' `"$$.      $$    `$b      $$
  `$\.  8$8  ./$'      Y$.   .$P     /'     $$.     $$      $      "$  .:$
    "$$##$##$$"         `'"#"'`                             '       `"'`"'
      `"Y#P"'
        |$|                       H  H   AA    CCC  K  K
        `$'                       HHHH  A__A  C     KKK
         $                        H  H  A  A   CCC  K  K
         *
---------------------------------------------------------------------------
(logo viewed best in fixed width / terminal fonts)


alpha Release

0.6 - released 12.25.14

---------------------------------------------------------------------------

readme.txt update: 12.22.14
---------------------------------------------------------------------------

Instructions - unpack this file in your quake directory

unzip qh1.zip


to launch singleplayer game:

Linux:

   maphack-glx -game quake_hack +coop 1 +map qh_0000

win:

   maphack.exe -game quake_hack +coop 1 +map qh_0000


to launch (real) coop game:

Linux:

   maphack-glx -listen -game quake_hack +coop 1 +exec coop.cfg +map qh_0000

win:

   maphack.exe  -listen -game quake_hack +coop 1 +exec coop.cfg +map qh_0000


Deathmatch will function as normal.  There are 32 map sections.
Good luck with this.

   maphack-glx -listen -game quake_hack +map qh_0000
   maphack-glx -dedicated -game quake_hack +map qh_0000


* To connect a client to a listen or dedicated coop server:

Linux:
maphack-glx -game quake_hack

Win:
maphack.exe  -game quake_hack

If you know the ip address of the server enter in the console:
connect {ip address}

Or:

From the main menu, select in sequence:
Multiplayer
Join a game
search for games

Select the ip address of the server you wish to play.


Note:

"+coop 1" is required for singleplayer and coop
"+exec coop.cfg" is required for regular coop play

---------------------------------------------------------------------------

Game play:

Plays just like quake.

Without any wimpy breaks.  Suck it up Marine!

You run, you shoot, you get runes, you stop shubbs or you die.

---------------------------------------------------------------------------

Other notes:

You can NOT reload quake_hack with map, changelevel, or by normal single player respawn.
This is new map tech and those methods will fail.  If you need to, use savegame to save your progress.

This is one reason +coop 1 must be set for singleplayer.  The other is area respawns.
When you respawn you have the standard 2 mins to go find your pack of goodies.
Try not to die in lava.  If you lose a key - they eventually come back.  Just wait.

Intermission messages are set to scroll on the infobar at the bottom of the screen.
To turn them off, enter in the console:

sv_intermis		0


---------------------------------------------------------------------------
See "source code/code_updates_fixes.txt" for bug fix list and developer notes.

This is _beta_ qc / engine code - it might still contain bugs.

---------------------------------------------------------------------------

Bots:

Bots were not included in the 1.0 release.
They may be included in a future release for coop play.  After I test them.



Have fun!

---------------------------------------------------------------------------

                    Quake Hack

